<!DOCTYPE html>
<html>
<head>
</head>
<body>
    <h2>{{ $data['title'] }}</h2>
    <p>{{ $data['content'] }}</p>
</body>
</html>