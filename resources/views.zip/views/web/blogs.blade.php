

@extends('web.layouts.main')
@section('content')

<h1> No blogs<h1>
                           
   


    @endsection
@push('scripts')

@endpush

