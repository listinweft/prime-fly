<div class="col-lg-5 cart-price-summry">
                                <h4>Price Details</h4>
                                <div class="price-summery">
                                    <table>
                                        <tbody>
                                            <tr>
                                                <td>Executive Departure </td>
                                                <td>&#8377; 2,456.5</td>
                                            </tr>
                                           
                                            
                                            
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td><b>Total Amount</b></td>
                                                <td><b>&#8377; {{ number_format(Cart::session($sessionKey)->getSubTotal(),2)}}</b></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                    <div class="col-12 package-content-button text-center mt-3">
                                        <a href="" class="btn btn-primary">Continue</a>
                                    </div>
                                </div>
                            </div>