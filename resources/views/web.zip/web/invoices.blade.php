<!DOCTYPE html>
<html>
<head>
    <style>
        /* Define your styles for the PDF here */
        body {
            font-family: Arial, sans-serif;
        }
        .invoice {
            margin-bottom: 20px;
            padding: 20px;
            border: 1px solid #ccc;
            background-color: #f9f9f9;
        }
        .order_header {
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ccc;
        }
        .order_details_item {
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #ccc;
        }
        .price_area {
            list-style: none;
            padding: 0;
            margin: 0;
        }
    </style>
</head>
<body>
    <div class="invoice">
        <div class="order_header">
            
        </div>
        
        

       
    </div>
</body>
</html>
